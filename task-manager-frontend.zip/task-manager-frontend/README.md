# Task Manager Frontend

React + Vite single-page app that consumes a REST API (built in WA-2) for managing tasks.

## Features
- React Router: list (`/`), detail (`/tasks/:id`), create (`/tasks/new`), edit (`/tasks/:id/edit`), 404 page
- All data fetched from the API; no mock data
- Visible loading spinners, error messages with retry, empty states
- Client-side form validation (title 3–100 chars, description ≤ 500, valid status)
- State: `useState` + a small `useFetch` hook; `useContext` for flash messages
- Responsive layout (mobile + desktop), light/dark aware

## Run it
```bash
npm install
cp .env.example .env     # then edit .env
npm run dev              # http://localhost:5173
npm run build            # production build into dist/
```

## Pointing it at your API
Edit `.env`:
```
VITE_API_URL=http://localhost:3000/api
VITE_RESOURCE=tasks
```
The app calls `GET/POST {VITE_API_URL}/{VITE_RESOURCE}` and `GET/PUT/DELETE {VITE_API_URL}/{VITE_RESOURCE}/:id`.
Restart `npm run dev` after changing `.env`.

Expected task shape: `{ id (or _id), title, description, status: "todo" | "doing" | "done" }`.
Responses may be a bare array/object or wrapped as `{ "data": ... }`.

### CORS
Your API must allow requests from `http://localhost:5173` (e.g. `app.use(cors())` in Express).

## Project structure
```
src/
  api.js            fetch wrapper + error handling
  hooks/useFetch.js data-loading hook (loading / error / refetch)
  context/          flash message context
  components/       Spinner, ErrorMessage, StatusBadge
  pages/            TaskList, TaskDetail, TaskForm, NotFound
```
