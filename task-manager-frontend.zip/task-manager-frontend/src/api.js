const BASE = (import.meta.env.VITE_API_URL || "http://localhost:3000/api").replace(/\/$/, "");
const RESOURCE = import.meta.env.VITE_RESOURCE || "tasks";

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function request(path = "", options = {}) {
  let res;
  try {
    res = await fetch(`${BASE}/${RESOURCE}${path}`, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
  } catch (err) {
    if (err.name === "AbortError") throw err;
    throw new ApiError(`Cannot reach the API at ${BASE}. Is the server running?`, 0);
  }

  if (!res.ok) {
    let detail = "";
    try {
      const body = await res.json();
      detail = body.message || body.error || "";
    } catch {
      /* response had no JSON body */
    }
    throw new ApiError(detail || `Request failed (${res.status} ${res.statusText})`, res.status);
  }
  return res.status === 204 ? null : res.json();
}

// Some APIs return [..], others { data: [..] }
const unwrap = (body) => (body && !Array.isArray(body) && body.data !== undefined ? body.data : body);

export const getId = (item) => item?.id ?? item?._id;

export const api = {
  list: async (signal) => unwrap(await request("", { signal })),
  get: async (id, signal) => unwrap(await request(`/${id}`, { signal })),
  create: async (data) => unwrap(await request("", { method: "POST", body: JSON.stringify(data) })),
  update: async (id, data) => unwrap(await request(`/${id}`, { method: "PUT", body: JSON.stringify(data) })),
  remove: (id) => request(`/${id}`, { method: "DELETE" }),
};
