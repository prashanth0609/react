export function Spinner({ label = "Loading…" }) {
  return (
    <div className="center" role="status">
      <span className="spinner" aria-hidden="true" />
      <span>{label}</span>
    </div>
  );
}

export function ErrorMessage({ error, onRetry }) {
  return (
    <div className="error-box" role="alert">
      <strong>Something went wrong.</strong>
      <p>{error?.message || "Unknown error"}</p>
      {onRetry && (
        <button className="btn" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}

export function StatusBadge({ status }) {
  const labels = { todo: "To do", doing: "In progress", done: "Done" };
  return <span className={`badge badge-${status}`}>{labels[status] || status}</span>;
}
