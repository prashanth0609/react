import { createContext, useCallback, useContext, useState } from "react";

const FlashContext = createContext(null);

export function FlashProvider({ children }) {
  const [message, setMessage] = useState(null);

  const flash = useCallback((text) => {
    setMessage(text);
    setTimeout(() => setMessage(null), 3500);
  }, []);

  return (
    <FlashContext.Provider value={flash}>
      {children}
      {message && (
        <div className="flash" role="status">
          {message}
        </div>
      )}
    </FlashContext.Provider>
  );
}

export const useFlash = () => useContext(FlashContext);
