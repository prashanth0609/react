import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="card">
      <h1>Page not found</h1>
      <p>That address doesn't match any page in this app.</p>
      <Link to="/" className="btn btn-primary">
        Go to tasks
      </Link>
    </div>
  );
}
