import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api, getId } from "../api";
import useFetch from "../hooks/useFetch";
import { useFlash } from "../context/FlashContext";
import { ErrorMessage, Spinner, StatusBadge } from "../components/Status";

export default function TaskDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const flash = useFlash();
  const { data: task, loading, error, refetch } = useFetch((s) => api.get(id, s), [id]);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState(null);

  async function handleDelete() {
    if (!window.confirm("Delete this task? This can't be undone.")) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      await api.remove(id);
      flash("Task deleted");
      navigate("/");
    } catch (err) {
      setDeleteError(err);
      setDeleting(false);
    }
  }

  if (loading) return <Spinner label="Loading task…" />;
  if (error?.status === 404)
    return (
      <ErrorMessage error={{ message: "That task doesn't exist. It may have been deleted." }} />
    );
  if (error) return <ErrorMessage error={error} onRetry={refetch} />;
  if (!task) return null;

  return (
    <article className="card">
      <Link to="/" className="back">
        ← All tasks
      </Link>
      <h1>{task.title}</h1>
      <StatusBadge status={task.status} />
      <p className="description">{task.description || "No description."}</p>

      {deleteError && <ErrorMessage error={deleteError} />}

      <div className="actions">
        <Link to={`/tasks/${getId(task)}/edit`} className="btn btn-primary">
          Edit task
        </Link>
        <button className="btn btn-danger" onClick={handleDelete} disabled={deleting}>
          {deleting ? "Deleting…" : "Delete task"}
        </button>
      </div>
    </article>
  );
}
