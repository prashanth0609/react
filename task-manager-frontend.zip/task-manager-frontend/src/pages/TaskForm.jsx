import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "../api";
import useFetch from "../hooks/useFetch";
import { useFlash } from "../context/FlashContext";
import { ErrorMessage, Spinner } from "../components/Status";

const EMPTY = { title: "", description: "", status: "todo" };

function validate(values) {
  const errors = {};
  const title = values.title.trim();
  if (!title) errors.title = "Enter a title.";
  else if (title.length < 3) errors.title = "Title must be at least 3 characters.";
  else if (title.length > 100) errors.title = "Title must be 100 characters or fewer.";
  if (values.description.length > 500) errors.description = "Description must be 500 characters or fewer.";
  if (!["todo", "doing", "done"].includes(values.status)) errors.status = "Choose a status.";
  return errors;
}

export default function TaskForm() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const flash = useFlash();

  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [submitError, setSubmitError] = useState(null);

  // Only hits the API when editing
  const { data, loading, error, refetch } = useFetch(
    (signal) => (isEdit ? api.get(id, signal) : Promise.resolve(null)),
    [id]
  );

  useEffect(() => {
    if (data) setValues({ title: data.title ?? "", description: data.description ?? "", status: data.status ?? "todo" });
  }, [data]);

  function handleChange(e) {
    const { name, value } = e.target;
    const next = { ...values, [name]: value };
    setValues(next);
    if (errors[name]) setErrors(validate(next)); // re-check as the user fixes a field
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length) return;

    setSaving(true);
    setSubmitError(null);
    const payload = { ...values, title: values.title.trim() };
    try {
      if (isEdit) await api.update(id, payload);
      else await api.create(payload);
      flash(isEdit ? "Task updated" : "Task created");
      navigate("/");
    } catch (err) {
      setSubmitError(err);
      setSaving(false);
    }
  }

  if (isEdit && loading) return <Spinner label="Loading task…" />;
  if (isEdit && error) return <ErrorMessage error={error} onRetry={refetch} />;

  return (
    <form className="card" onSubmit={handleSubmit} noValidate>
      <Link to={isEdit ? `/tasks/${id}` : "/"} className="back">
        ← Cancel
      </Link>
      <h1>{isEdit ? "Edit task" : "New task"}</h1>

      <label htmlFor="title">Title</label>
      <input id="title" name="title" value={values.title} onChange={handleChange} aria-invalid={!!errors.title} />
      {errors.title && <p className="field-error">{errors.title}</p>}

      <label htmlFor="description">Description</label>
      <textarea
        id="description"
        name="description"
        rows="5"
        value={values.description}
        onChange={handleChange}
        aria-invalid={!!errors.description}
      />
      <p className="hint">{values.description.length}/500</p>
      {errors.description && <p className="field-error">{errors.description}</p>}

      <label htmlFor="status">Status</label>
      <select id="status" name="status" value={values.status} onChange={handleChange}>
        <option value="todo">To do</option>
        <option value="doing">In progress</option>
        <option value="done">Done</option>
      </select>
      {errors.status && <p className="field-error">{errors.status}</p>}

      {submitError && <ErrorMessage error={submitError} />}

      <button className="btn btn-primary" type="submit" disabled={saving}>
        {saving ? "Saving…" : isEdit ? "Save changes" : "Create task"}
      </button>
    </form>
  );
}
