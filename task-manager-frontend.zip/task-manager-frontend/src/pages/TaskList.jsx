import { Link } from "react-router-dom";
import { api, getId } from "../api";
import useFetch from "../hooks/useFetch";
import { ErrorMessage, Spinner, StatusBadge } from "../components/Status";

export default function TaskList() {
  const { data, loading, error, refetch } = useFetch((signal) => api.list(signal));

  if (loading) return <Spinner label="Loading tasks…" />;
  if (error) return <ErrorMessage error={error} onRetry={refetch} />;

  const tasks = Array.isArray(data) ? data : [];

  return (
    <>
      <div className="page-head">
        <h1>Tasks</h1>
        <Link to="/tasks/new" className="btn btn-primary">
          Add task
        </Link>
      </div>

      {tasks.length === 0 ? (
        <p className="empty">No tasks yet. Add your first one to get started.</p>
      ) : (
        <ul className="task-list">
          {tasks.map((t) => (
            <li key={getId(t)}>
              <Link to={`/tasks/${getId(t)}`} className="task-row">
                <span className="task-title">{t.title}</span>
                <StatusBadge status={t.status} />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
